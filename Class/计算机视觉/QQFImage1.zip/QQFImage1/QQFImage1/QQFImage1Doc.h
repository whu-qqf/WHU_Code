﻿
// QQFImage1Doc.h: CQQFImage1Doc 类的接口
//


#pragma once
#include<opencv2/opencv.hpp> //OpenCV 3.0头文件
#include<opencv2/core/core.hpp> //OpenCV 3.0头文件
#include<opencv2/imgproc/imgproc.hpp> //OpenCV 3.0头文件
#include<opencv2/highgui/highgui.hpp> //OpenCV 3.0头文件
#include<opencv2/imgcodecs.hpp> //OpenCV 3.0头文件

class CQQFImage1Doc : public CDocument
{
protected: // 仅从序列化创建
	CQQFImage1Doc() noexcept;
	DECLARE_DYNCREATE(CQQFImage1Doc)

// 特性
public:

	IplImage* image;//OpenCV图像指针

	BITMAPINFO* lpbmi;
	unsigned char* m_pBits;
	BITMAPFILEHEADER bmpFH;
	int imageWidth;
	int imageHeight;
	int m_nColorBits;//8 24
	int m_nOpenMode;//=0 RAW =1 BMP =2 OpenCV

// 操作
public:

	//void ReadRAW(LPCTSTR lpszPathName, int nWidth, int nHeight);
	BOOL ReadBMP(LPCTSTR lpszPathName);     //读取BMP图像
	BOOL SaveBMP(LPCTSTR lpszPathName);     //保存BMP图像

// 重写
public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
#ifdef SHARED_HANDLERS
	virtual void InitializeSearchContent();
	virtual void OnDrawThumbnail(CDC& dc, LPRECT lprcBounds);
#endif // SHARED_HANDLERS

// 实现
public:
	virtual ~CQQFImage1Doc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// 生成的消息映射函数
protected:
	DECLARE_MESSAGE_MAP()

#ifdef SHARED_HANDLERS
	// 用于为搜索处理程序设置搜索内容的 Helper 函数
	void SetSearchContent(const CString& value);
#endif // SHARED_HANDLERS
public:
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
	virtual BOOL OnSaveDocument(LPCTSTR lpszPathName);
};
