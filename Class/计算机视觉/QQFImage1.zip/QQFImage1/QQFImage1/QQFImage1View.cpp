﻿
// QQFImage1View.cpp: CQQFImage1View 类的实现
//

#include "pch.h"
#include "framework.h"
#include"MainFrm.h"
#include<cmath>
#include"QYZZ.h"
// SHARED_HANDLERS 可以在实现预览、缩略图和搜索筛选器句柄的
// ATL 项目中进行定义，并允许与该项目共享文档代码。
#ifndef SHARED_HANDLERS
#include "QQFImage1.h"
#include"CHistogramDisply.h"
#include"SmoothDlg.h"
#include"JHBHDlg.h"
#include"KaoheDlg.h"
#endif

#include "QQFImage1Doc.h"
#include "QQFImage1View.h"
#include"core.hpp"
#include"highgui.hpp"
#include"imgproc.hpp"
#include"opencv/cv.h"
#include"opencv/cvaux.hpp"
#include"opencv/cxcore.h"
#include<iostream>
#include<stdio.h>
#include<string>
#include<stdarg.h>
#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CQQFImage1View
using namespace std;
using namespace cv;

IMPLEMENT_DYNCREATE(CQQFImage1View, CScrollView)

BEGIN_MESSAGE_MAP(CQQFImage1View, CScrollView)
	// 标准打印命令
	ON_COMMAND(ID_FILE_PRINT, &CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CScrollView::OnFilePrintPreview)
	ON_COMMAND(ID_VIEW_ZOOM_OUT, &CQQFImage1View::OnViewZoomOut)
	ON_COMMAND(ID_VIEW_ZOOM_IN, &CQQFImage1View::OnViewZoomIn)
	ON_WM_MOUSEMOVE()
	ON_COMMAND(ID_OPENCV1, &CQQFImage1View::OnOpencv1)
	ON_COMMAND(ID_PROCESS_LINETRAN, &CQQFImage1View::OnProcessLinetran)
	ON_COMMAND(ID_PROCESS_ZHIFANGTU, &CQQFImage1View::OnProcessZhifangtu)
	ON_COMMAND(ID_DrawGraph, &CQQFImage1View::OnDrawgraph)
	ON_COMMAND(ID_IMAGE_SMOOTH, &CQQFImage1View::OnImageSmooth)
	ON_COMMAND(ID_FSBH, &CQQFImage1View::OnFsbh)
	ON_COMMAND(ID_FREQ_FOUR, &CQQFImage1View::OnFreqFour)
	ON_COMMAND(ID_BUTTERWORTH_LOW, &CQQFImage1View::OnButterworthLow)
	ON_COMMAND(ID_BUTTERWORTH_HIGH, &CQQFImage1View::OnButterworthHigh)
	ON_COMMAND(ID_OSTU_SEGMENTATION, &CQQFImage1View::OnOstuSegmentation)
	ON_COMMAND(ID_REGION_GROWING, &CQQFImage1View::OnRegionGrowing)
	ON_COMMAND(ID_IMAGE_EX, &CQQFImage1View::OnImageEx)
END_MESSAGE_MAP()

// CQQFImage1View 构造/析构

CQQFImage1View::CQQFImage1View() noexcept
{
	// TODO: 在此处添加构造代码
	m_dZoom = 1.0;
	m_bShow = FALSE;

}

CQQFImage1View::~CQQFImage1View()
{
}

BOOL CQQFImage1View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: 在此处通过修改
	//  CREATESTRUCT cs 来修改窗口类或样式

	return CScrollView::PreCreateWindow(cs);
}

// CQQFImage1View 绘图

void CQQFImage1View::OnDraw(CDC* pDC)
{
	CQQFImage1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	CSize sizeTotal;
	sizeTotal.cx = pDoc->imageWidth;
	sizeTotal.cy = pDoc->imageHeight;
	SetScrollSizes(MM_TEXT, sizeTotal);

	if (pDoc->m_nOpenMode == 1)//BMP
	{
		//利用m_dZoom因子改变图像大小
		StretchDIBits(pDC->m_hDC, 0, 0,
			int(m_dZoom*pDoc->imageWidth+0.5), int(m_dZoom*pDoc->imageHeight+0.5), 0, 0, pDoc->imageWidth, pDoc->imageHeight,
			pDoc->m_pBits, pDoc->lpbmi, DIB_RGB_COLORS, SRCCOPY);
	}
	if (pDoc->m_nOpenMode == 2)//JPG
	{
		StretchDIBits(pDC->m_hDC, 0, 0, int(m_dZoom*pDoc->image->width+0.5), int(m_dZoom*pDoc->image->height+0.5), 0, pDoc->image->height, pDoc->image->width, -pDoc->image->height, pDoc->image->imageData, pDoc->lpbmi, DIB_RGB_COLORS, SRCCOPY);
		// TODO: 在此处为本机数据添加绘制代码
	}
	if (m_bShow)
		DrawGraph(pDC);
}

void CQQFImage1View::OnInitialUpdate()
{
	CScrollView::OnInitialUpdate();

	CSize sizeTotal;
	// TODO: 计算此视图的合计大小
	sizeTotal.cx = sizeTotal.cy = 100;
	SetScrollSizes(MM_TEXT, sizeTotal);
}


// CQQFImage1View 打印

BOOL CQQFImage1View::OnPreparePrinting(CPrintInfo* pInfo)
{
	// 默认准备
	return DoPreparePrinting(pInfo);
}

void CQQFImage1View::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 添加额外的打印前进行的初始化过程
}

void CQQFImage1View::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 添加打印后进行的清理过程
}


// CQQFImage1View 诊断

#ifdef _DEBUG
void CQQFImage1View::AssertValid() const
{
	CScrollView::AssertValid();
}

void CQQFImage1View::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

CQQFImage1Doc* CQQFImage1View::GetDocument() const 
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CQQFImage1Doc)));
	return (CQQFImage1Doc*)m_pDocument;
}
#endif //_DEBUG


// CQQFImage1View 消息处理程序


void CQQFImage1View::OnViewZoomOut()   //图像放大
{
	// TODO: 在此添加命令处理程序代码
	m_dZoom = m_dZoom * 2;
	Invalidate();
}


void CQQFImage1View::OnViewZoomIn()   //图像缩小
{
	// TODO: 在此添加命令处理程序代码
	m_dZoom = m_dZoom / 2;
	Invalidate();
}


void CQQFImage1View::OnMouseMove(UINT nFlags, CPoint point)
{
	CQQFImage1Doc* pDoc = GetDocument();  //获取文档指针
	if (pDoc->m_pBits != NULL || pDoc->image != NULL)  //检查图像数据的有效性
	{
		CPoint scrPoint = GetScrollPosition();   //获取滚动位置
		int nX = int(0.5 + (scrPoint.x + point.x) / m_dZoom);   //计算图像坐标，需要考虑缩放因素
		int nY = int(0.5 + (scrPoint.y + point.y) / m_dZoom);
		int nR, nG, nB;
		if (nX >= 0 && nX < pDoc->imageWidth && nY >= 0 && nY < pDoc->imageHeight)  //坐标位于图窗内
		{
			CString strPrompt;
			if (pDoc->m_nOpenMode == 1)    //处理BMP图像
			{
				if (pDoc->m_nColorBits == 8)    //灰度图
				{
					nB = *(pDoc->m_pBits + (pDoc->imageHeight - nY - 1) * pDoc->imageWidth + nX);
					strPrompt.Format(_T("X:%4d-Y:%4d Gray:%3d"), nX, nY, nB);
				}
				if (pDoc->m_nColorBits == 24)     //24位图像
				{
					nB = *(pDoc->m_pBits + (pDoc->imageHeight - nY - 1) * pDoc->imageWidth * 3 + nX * 3 + 0);
					nG = *(pDoc->m_pBits + (pDoc->imageHeight - nY - 1) * pDoc->imageWidth * 3 + nX * 3 + 1);
					nR = *(pDoc->m_pBits + (pDoc->imageHeight - nY - 1) * pDoc->imageWidth * 3 + nX * 3 + 2);
					strPrompt.Format(_T("X:%4d-Y:%4d R:%3d G:%3d B:%3d"), nX, nY, nR, nG, nB);
				}
			}
			if (pDoc->m_nOpenMode == 2)    //处理JPG
			{
				pDoc->m_pBits = (unsigned char*)pDoc->image->imageData;
				if (pDoc->image->nChannels == 1)    //黑白图像
				{
					nB = *(pDoc->m_pBits + nY * pDoc->imageWidth + nX);
					strPrompt.Format(_T("X:%4d-Y:%4d Gray:%3d"), nX, nY, nB);
				}
				if (pDoc->image->nChannels == 3)    //彩色图像
				{
					nB = *(pDoc->m_pBits + nY * pDoc->imageWidth * 3 + nX * 3 + 0);
					nG = *(pDoc->m_pBits + nY * pDoc->imageWidth * 3 + nX * 3 + 1);
					nR = *(pDoc->m_pBits + nY * pDoc->imageWidth * 3 + nX * 3 + 2);
					strPrompt.Format(_T("X:%4d-Y:%4d R:%3d G:%3d B:%3d"), nX, nY, nR, nG, nB);
				}
			}
			//在边栏显示像素信息
			((CMainFrame*)AfxGetMainWnd())->SetStatusBarText(1, strPrompt);
		}
	}
	CScrollView::OnMouseMove(nFlags, point);
}


void CQQFImage1View::OnOpencv1()
{
	// TODO: 在此添加命令处理程序代码
	int nRetCode = 0;
	CvPoint center;
	double scale = -3;
	CQQFImage1Doc* pDoc = GetDocument();
	IplImage* image = pDoc->image;
	if (!image)
	{
		image = cvLoadImage("D:\\HuaweiMoveData\\Users\\HUAWEI\\Desktop\\imagebmp.bmp");//-1;
	}

	cvNamedWindow("test0", 1);
	cvShowImage("test0", image);

	center = cvPoint(image->width / 2, image->height / 2);     //定义中心坐标
	for (int i = 0; i < image->height; i++)
		for (int j = 0; j < image->width; j++)
		{
			double dx = (double)(j - center.x) / center.x;    //列距离
			double dy = (double)(i - center.y) / center.y;    //行距离
			double weight = exp((dx * dx + dy * dy) * scale);   //衰减系数
			uchar* ptr = &CV_IMAGE_ELEM(image, uchar, i, j * 3);   //取图像像素灰度地址
			ptr[0] = cvRound(ptr[0] * weight);   //计算B分量
			ptr[1] = cvRound(ptr[1] * weight);   //计算G分量
			ptr[2] = cvRound(ptr[2] * weight);   //计算R分量
		}
	cvSaveImage("D:\\Copy.jpg", image);//保存位置
	cvNamedWindow("test", 1); //命名一个现实窗口展示图像
	cvShowImage("test", image);//显示图像 image
	cvWaitKey();
}


void CQQFImage1View::OnProcessLinetran()
{
	CQQFImage1Doc*pDoc = GetDocument();   //获取当前视窗的文档图像
	ASSERT_VALID(pDoc);
	unsigned char* pBits = pDoc->m_pBits;     //获取图像数据指针
	int nWidth = pDoc->imageWidth;       //获取图像宽度
	int nHeight = pDoc->imageHeight;     //获取图像高度
	//初始化用于颜色转换的变量
	int nValueR = 0;
	int nValueG = 0;
	int nValueB = 0;
	double dValueR = 0.0;
	double dValueG = 0.0;
	double dValueB = 0.0;
	long lTotalD = 0;     //当前像素的起始位置
	long lTotalL = 0;     //当前行的起始变量

	//定义颜色转换参数
	int ra = 105, rb = 200;     //R分量的目标范围
	int ga = 35, gb = 95;     //G分量的目标范围
	int ba = 95, bb = 105;      //B分量的目标范围
	int a = 0, b = 255;         //RGB初始的分量范围
	if (pBits == NULL) return;
	for (int i = 0; i < nHeight; i++)
	{
		lTotalL = nWidth * i;
		for (int j = 0; j < nWidth; j++)
		{
			//对R分量操作
			lTotalD = (lTotalL + j)*3;
			nValueR = pBits[lTotalD + 2];   //需要注意的是存储顺序是BGR
			dValueR = ra + 1.0 * (rb - ra) / (b - a) * (nValueR - a);
			pBits[lTotalD + 2] = int(dValueR);
			//对G分量操作
			nValueG = pBits[lTotalD + 1];
			dValueG = ga + 1.0 * (gb - ga) / (b - a) * (nValueG - a);
			pBits[lTotalD + 1] = int(dValueG);
			//对B分量操作
			nValueB = pBits[lTotalD];
			dValueB = ba + 1.0 * (bb - ba) / (b - a) * (nValueB - a);
			pBits[lTotalD] = int(dValueB);

		}
	}
	Invalidate();   //刷新视图
}


void CQQFImage1View::OnProcessZhifangtu()
{
	m_bShow = TRUE;      //改变标志，显示直方图
	CQQFImage1Doc* pDoc = GetDocument();      //获取当前图窗的指针
	ASSERT_VALID(pDoc);
	unsigned char* pBits = pDoc->m_pBits;      //获取图像数据指针
	int nWidth = pDoc->imageWidth;    //宽度
	int nHeight = pDoc->imageHeight;   //高度
	int nValue = 0;          //用于存储当前像素值
	long lTotal = 0;       //用于存储灰度或RGB值
	long lTotalD = 0;       //像素位置
	long lTotalL = 0;       //当前行的起始位置
	dMax = 0;      //灰度最大概率或者R分量最大概率
	dMaxG = 0;     //G分量最大概率
	dMaxB = 0;     //B分量最大概率
	if (pBits == NULL) return;
	if (pDoc->m_nColorBits == 8)      //灰度图
	{
		for (int k = 0; k < 256; k++)
		{
			m_lValue[k] = 0;        //初始化灰度出现的次数  
			m_dValue[k] = 0.0;     //初始化灰度概率直方图
		}
		for (int i = 0; i < nHeight; i++)
		{
			lTotalL = nWidth * i;      //行的起始位置
			for (int j = 0; j < nWidth; j++)
			{
				lTotalD = lTotalL + j;      //当前像素位置
				nValue = *(pBits + lTotalD);     //获取灰度值
				m_lValue[nValue] = m_lValue[nValue] + 1;    //统计该灰度出现的次数
			}
		}
		lTotal = nWidth * nHeight;     //总的像素数量
		for (int k = 0; k < 256; k++)
		{
			m_dValue[k] = 1.0 * m_lValue[k] / lTotal;    //计算灰度概率
			if (dMax < m_dValue[k]) dMax = m_dValue[k];     //更新最大概率值
		}
	}
	//对彩色图像的处理
	long nValueG = 0;     //用于存储绿色通道的像素值
	long nValueB = 0;     //用于存储蓝色通道的像素值
	if (pDoc->m_nColorBits == 24)    //彩色图像
	{
		for (int k = 0; k < 256; k++)
		{
			m_lValue[k] = 0;     //红色次数
			m_dValue[k] = 0.0;    //红色概率
			m_lValueG[k] = 0;    //绿色次数
			m_dValueG[k] = 0.0;  //绿色概率
			m_lValueB[k] = 0;    //蓝色次数
			m_dValueB[k] = 0.0;  //蓝色概率
		}
		for (int i = 0; i < nHeight; i++)
		{
			lTotalL = nWidth * i;
			for (int j = 0; j < nWidth; j++)
			{
				lTotalD = (lTotalL + j) * 3;     //当前像素位置，乘以3因为24位的带色图像每个像素有三个分量
				nValue = *(pBits + lTotalD + 2);    //注意存储顺序是BGR
				m_lValue[nValue] = m_lValue[nValue] + 1;      //红色像素次数

				nValueG = *(pBits + lTotalD + 1);
				m_lValueG[nValueG] = m_lValueG[nValueG] + 1;  //绿色像素次数

				nValueB = *(pBits + lTotalD);
				m_lValueB[nValueB] = m_lValueB[nValueB] + 1;  //蓝色像素次数
			}
		}
		lTotal = nWidth * nHeight;    //总像素
		//更新像素最大值频率
		for (int k = 0; k < 256; k++)
		{
			m_dValue[k] = 1.0 * m_lValue[k] / lTotal;
			if (dMax < m_dValue[k]) dMax = m_dValue[k];     //红色

			m_dValueG[k] = 1.0 * m_lValueG[k] / lTotal;
			if (dMaxG < m_dValueG[k]) dMaxG = m_dValueG[k];  //绿色

			m_dValueB[k] = 1.0 * m_lValueB[k] / lTotal; 
			if (dMaxB < m_dValueB[k]) dMaxB = m_dValueB[k];   //蓝色
		}
	}
	Invalidate();    //刷新视图
}


void CQQFImage1View::DrawGraph(CDC* pDC)
{
	CQQFImage1Doc* pDoc = GetDocument(); //获取当前图窗的指针
	ASSERT_VALID(pDoc);
	unsigned char* pBits = pDoc->m_pBits;   //获取图像数据的指针
	int X0 = 0 + 5;    //X轴起点，加上偏移量
	int Y0 = 510;     //Y轴起点
	int WX = 768 + 3, HY = 500;      //绘图区域的宽度和高度
	int H = 375;       //直方图的高度
	int W = 256;       //直方图的宽度
	CPen cyPen(PS_SOLID, 2, RGB(255, 255, 0));      //利用黄色画笔绘制边框
	CPen* oldPen = pDC->SelectObject(&cyPen);     //更新画笔颜色

	//开始绘图
	//绘制底边
	pDC->MoveTo(X0, Y0);      //MoveTo是表明起点处
	pDC->LineTo(X0 + WX, Y0);    //LineTo是画线终点处的坐标
	//绘制左边
	pDC->MoveTo(X0, Y0);
	pDC->LineTo(X0, Y0 - HY);
	//绘制顶边
	pDC->MoveTo(X0, Y0 - HY);
	pDC->LineTo(X0 + WX, Y0 - HY);
	//绘制右边
	pDC->MoveTo(X0 + WX, Y0);
	pDC->LineTo(X0 + WX, Y0 - HY);
	pDC->SelectObject(&oldPen);     //切换回旧的画笔
	{
		CPen redPen(PS_SOLID, 1, RGB(255, 0, 0));    //红色画笔用于绘制灰度直方图或者红色分量的直方图
		oldPen = pDC->SelectObject(&redPen);
		for (int i = 0; i < 256; i++)
		{
			int x0, y0, x1, y1;
			double dy;
			x0 = X0 + i * 3;
			y0 = Y0;
			x1 = X0 + i * 3;
			dy = Y0 - 1.0 * H * m_dValue[i] / dMax;    //计算绘图位置
			y1 = int(dy + 0.5);
			pDC->MoveTo(x0, y0);
			pDC->LineTo(x1, y1);     //绘制灰度直方图或者红色分量直方图
		}
		pDC->SelectObject(oldPen);
	}
	if (pDoc->m_nColorBits == 24)
	{
		{
			CPen grnPen(PS_SOLID, 1, RGB(0, 255, 0));    //绘制绿色分量的直方图
			oldPen = pDC->SelectObject(&grnPen);     //使用绿色画笔
			for (int i = 0; i < 256; i++)
			{
				int x0, y0, x1, y1;
				double dy;
				x0 = X0 + i * 3 + 1;
				y0 = Y0;
				x1 = X0 + i * 3 + 1;
				dy = Y0 - 1.0 * H * m_dValueG[i] / dMaxG;
				y1 = int(dy + 0.5);
				pDC->MoveTo(x0, y0);
				pDC->LineTo(x1, y1);
			}
			pDC->SelectObject(oldPen);
		}
		{
			CPen grnPen(PS_SOLID, 1, RGB(0, 0, 255));    //绘制蓝色分量直方图
			oldPen = pDC->SelectObject(&grnPen);     //使用蓝色画笔
			for (int i = 0; i < 256; i++)
			{
				int x0, y0, x1, y1;
				double dy;
				x0 = X0 + i * 3 + 2;
				y0 = Y0;
				x1 = X0 + i * 3 + 2;
				dy = Y0 - 1.0 * H * m_dValueB[i] / dMaxB;
				y1 = int(dy + 0.5);
				pDC->MoveTo(x0, y0);
				pDC->LineTo(x1, y1);
			}
			pDC->SelectObject(oldPen);
		}
	}
}


void CQQFImage1View::OnDrawgraph()
{
	CQQFImage1Doc* pDoc = GetDocument();     //获取当前图窗的指针
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	if (pDoc->m_nOpenMode == 2)  //JPG图像
	{
		pDoc->imageWidth = pDoc->image->width;   //获取图像宽度
		pDoc->imageHeight = pDoc->image->height;    //获取图像高度
		pDoc->m_nColorBits = pDoc->image->nChannels * pDoc->image->depth;     //获取图像的位深度
		pDoc->m_pBits = (unsigned char*)pDoc->image->imageData;     //获取图像的数据
	}
	unsigned char* pBits = pDoc->m_pBits;      //图像的数据指针
	int nWidth = pDoc->imageWidth;          //宽度
	int nHeight = pDoc->imageHeight;      //高度
	int nValue = 0;          //值，用于存储灰度值或者RGB值
	long lTotal = 0;         //像素总数
	long lTotalD = 0;        //当前像素的位置
	long lTotalL = 0;        //当前行的起始位置
	dMax = 0;      //灰度最大概率或者R分量最大概率
	dMaxG = 0;     //G分量最大概率
	dMaxB = 0;     //B分量最大概率
	if (pDoc->m_nColorBits == 8)    //灰度图像
	{
		for (int k = 0; k < 256; k++)
		{
			m_lValue[k] = 0;       //初始化灰度值
			m_dValue[k] = 0.0;      //初始化灰度概率
		}
		for (int i = 0; i < nHeight; i++)
		{
			lTotalL = nWidth * i;      //当前行的起始位置
			for (int j = 0; j < nWidth; j++)
			{
				lTotalD = lTotalL + j;       //当前像素的位置
				nValue = *(pBits + lTotalD);     //获取灰度值
				m_lValue[nValue] = m_lValue[nValue] + 1;    //该灰度值数量加1 
			}
		}
		lTotal = nWidth * nHeight;        //总的像素值
		for (int k = 0; k < 256; k++)
		{
			m_dValue[k] = 1.0 * m_lValue[k] / lTotal;       //计算概率
			if (dMax < m_dValue[k])dMax = m_dValue[k];        //更新最大值
		}
	}

	//对G和B分量做处理
	long nValueG = 0;      //存储G分量的像素值
	long nValueB = 0;      //存储B分量的像素值
	if (pDoc->m_nColorBits == 24)    //24位彩色图像
	{
		for (int k = 0; k < 256; k++)
		{
			//红色分量初始化
			m_lValue[k] = 0;
			m_dValue[k] = 0.0;
			//绿色分量初始化
			m_lValueG[k] = 0;
			m_dValueG[k] = 0.0;
			//蓝色分量初始化
			m_lValueB[k] = 0;
			m_dValueB[k] = 0.0;
		}
		for (int i = 0; i < nHeight; i++)
		{
			lTotalL = nWidth * i;
			for (int j = 0; j < nWidth; j++)
			{
				lTotalD =( lTotalL + j) * 3;  //当前像素位置，因为24位彩色图像每个像素有3个通道，所以乘三
				//统计蓝色分量
				nValueB = *(pBits + lTotalD);
				m_lValueB[nValueB] = m_lValueB[nValueB] + 1;
				//统计绿色分量
				nValueG = *(pBits + lTotalD + 1);
				m_lValueG[nValueG] = m_lValueG[nValueG] + 1;
				//统计红色分量
				nValue = *(pBits + lTotalD + 2);
				m_lValue[nValue] = m_lValue[nValue] + 1;
			}
		}
		lTotal = nWidth * nHeight;
		for (int k = 0; k < 256; k++)
		{
			m_dValue[k] = 1.0 * m_lValue[k] / lTotal;     //计算红色通道的概率
			if (dMax < m_dValue[k])dMax = m_dValue[k];    //更新最大概率
			m_dValueG[k] = 1.0 * m_lValueG[k] / lTotal;
			if (dMaxG < m_dValueG[k])dMaxG = m_dValueG[k];
			m_dValueB[k] = 1.0 * m_lValueB[k] / lTotal;
			if (dMaxB < m_dValueB[k])dMaxB = m_dValueB[k];
		}
	}
	Invalidate();
    CHistogramDisply hisDlg;     //创建直方图对话框对象
	//为变量赋值
	hisDlg.m_nColorBits = pDoc->m_nColorBits;
	hisDlg.dMax = dMax;
	hisDlg.dMaxG = dMaxG;
	hisDlg.dMaxB = dMaxB;

	memcpy(hisDlg.m_dValue, m_dValue, 256 * sizeof(double));   //memcpy用于复制数据
	memcpy(hisDlg.m_dValueG, m_dValueG, 256 * sizeof(double));
	memcpy(hisDlg.m_dValueB, m_dValueB, 256 * sizeof(double));
	hisDlg.DoModal();    //显示直方图对话框
}


void CQQFImage1View::OnImageSmooth()
{
	SmoothDlg sdlg;    //创建一个平滑对话框对象
	if (sdlg.DoModal())
	{
		double  H[3][3];//声明一个3×3模板变量 
		double K = sdlg.m_nSmooth10;//H 与 K组合为8-领域平均法，k为模板因子 
		H[0][0] = sdlg.m_nSmooth1;// 声明模板变量赋值 
		H[0][1] = sdlg.m_nSmooth2;
		H[0][2] = sdlg.m_nSmooth3;
		H[1][0] = sdlg.m_nSmooth4;
		H[1][1] = sdlg.m_nSmooth5;
		H[1][2] = sdlg.m_nSmooth6;
		H[2][0] = sdlg.m_nSmooth7;
		H[2][1] = sdlg.m_nSmooth8;
		H[2][2] = sdlg.m_nSmooth9;
		CQQFImage1Doc* pDoc = GetDocument();  //获取当前图窗指针
		ASSERT_VALID(pDoc);
		unsigned char* pBits = pDoc->m_pBits;   //获取图像数据指针
		if (!pBits)
			return;
		int nWidth = pDoc->imageWidth;   //获取宽度
		int nHeight = pDoc->imageHeight;   //获取高度
		long lTotalR, lTotal;    //当前的所在图像位置
		int m, n;
		double dValue;    //存储RGB值或者灰度值
		double Value[3][3];   //存储3×3领域里的值
		unsigned char* pOldBits = NULL;//分配内存 
		int linebyte = pDoc->image->widthStep;
		if (pDoc->m_nColorBits == 8)      //处理灰度图像
		{
			//pOldBits = new unsigned char[nWidth * nHeight];    //为原始图像数据分配内存
			//CopyMemory(pOldBits, pBits, nWidth * nHeight);   //复制原始图像数据
			pOldBits = new unsigned char[linebyte * nHeight];//为原始图像数据分配内存 
			CopyMemory(pOldBits, pBits, linebyte * nHeight);//把图像复制到pOldBit 
			for (int i = 0; i < nHeight; i++)
			{
				//lTotalR = i * nWidth;
				lTotalR = i * linebyte;
				for (int j = 0; j < nWidth; j++)
				{
					lTotal = lTotalR + j;
					if (i == 0 || i == nHeight - 1 || j == 0 || j == nWidth - 1)//边缘点不作处理，直接拷贝数据
					{
					 pBits[lTotal] = pOldBits[lTotal];
					}
					else//内部点作平滑处理， 
					{
						/*Value[0][0] = pOldBits[lTotal - nWidth - 1];
						Value[0][1] = pOldBits[lTotal - nWidth - 0];
						Value[0][2] = pOldBits[lTotal - nWidth + 1];
						Value[1][0] = pOldBits[lTotal - 0 - 1];
						Value[1][1] = pOldBits[lTotal - 0 - 0];
						Value[1][2] = pOldBits[lTotal - 0 + 1];
						Value[2][0] = pOldBits[lTotal + nWidth - 1];
						Value[2][1] = pOldBits[lTotal + nWidth - 0];
						Value[2][2] = pOldBits[lTotal + nWidth + 1];*/
						Value[0][0] = pOldBits[lTotal - linebyte - 1];
						Value[0][1] = pOldBits[lTotal - linebyte - 0];
						Value[0][2] = pOldBits[lTotal - linebyte + 1];
						Value[1][0] = pOldBits[lTotal - 0 - 1];
						Value[1][1] = pOldBits[lTotal - 0 - 0];
						Value[1][2] = pOldBits[lTotal - 0 + 1];
						Value[2][0] = pOldBits[lTotal + linebyte - 1];
						Value[2][1] = pOldBits[lTotal + linebyte - 0];
						Value[2][2] = pOldBits[lTotal + linebyte + 1];

						dValue = 0.0;

						for (m = 0; m < 3; m++)
							for (n = 0; n < 3; n++)
								dValue = dValue + H[m][n] * Value[m][n];   //进行模板运算
						dValue = dValue * K;
						//像素超限问题解决
						if (dValue > 255) dValue = 255;
						if (dValue < 0)   dValue = 0;
						pBits[lTotal] = int(dValue + 0.5);   //将平滑后的值赋给当前像素
					}
				}
			}
			Invalidate();   //更新显示
			delete pOldBits;    //释放内存
		}
		else if (pDoc->m_nColorBits == 24)    //24位真彩色图像
		{
			//pOldBits = new unsigned char[3 * nWidth * nHeight];//为原始图像数据分配内存 
			//CopyMemory(pOldBits, pBits, 3 * nWidth * nHeight);//把图像复制到pOldBit 
			pOldBits = new unsigned char[linebyte* nHeight];//为原始图像数据分配内存 
			CopyMemory(pOldBits, pBits, linebyte * nHeight);//把图像复制到pOldBit 
			for (int i = 0; i < nHeight; i++)
			{
				//lTotalR = i * nWidth;
				lTotalR = i * linebyte;
				for (int j = 0; j < nWidth; j++)
				{
					//lTotal = (lTotalR + j) * 3;
					lTotal = lTotalR + j * 3;
					if (i == 0 || i == nHeight - 1 || j == 0 || j == nWidth - 1)//边缘点不作处理，直接拷贝数据
					{
					 pBits[lTotal + 0] = pOldBits[lTotal + 0];
					 pBits[lTotal + 1] = pOldBits[lTotal + 1];
					 pBits[lTotal + 2] = pOldBits[lTotal + 2];
					}
					else
					{
						//处理蓝色通道
						/*Value[0][0] = pOldBits[lTotal - 3 * nWidth - 3 * 1 + 0];
						Value[0][1] = pOldBits[lTotal - 3 * nWidth - 3 * 0 + 0];
						Value[0][2] = pOldBits[lTotal - 3 * nWidth + 3 * 1 + 0];
						Value[1][0] = pOldBits[lTotal - 3 * 0 - 3 * 1 + 0];
						Value[1][1] = pOldBits[lTotal - 3 * 0 - 3 * 0 + 0];
						Value[1][2] = pOldBits[lTotal - 3 * 0 + 3 * 1 + 0];
						Value[2][0] = pOldBits[lTotal + 3 * nWidth - 3 * 1 + 0];
						Value[2][1] = pOldBits[lTotal + 3 * nWidth - 3 * 0 + 0];
						Value[2][2] = pOldBits[lTotal + 3 * nWidth + 3 * 1 + 0];*/
						Value[0][0] = pOldBits[lTotal - linebyte - 3 * 1 + 0];
						Value[0][1] = pOldBits[lTotal - linebyte - 3 * 0 + 0];
						Value[0][2] = pOldBits[lTotal - linebyte + 3 * 1 + 0];
						Value[1][0] = pOldBits[lTotal - 3 * 0 - 3 * 1 + 0];
						Value[1][1] = pOldBits[lTotal - 3 * 0 - 3 * 0 + 0];
						Value[1][2] = pOldBits[lTotal - 3 * 0 + 3 * 1 + 0];
						Value[2][0] = pOldBits[lTotal + linebyte - 3 * 1 + 0];
						Value[2][1] = pOldBits[lTotal + linebyte - 3 * 0 + 0];
						Value[2][2] = pOldBits[lTotal + linebyte + 3 * 1 + 0];
						dValue = 0.0;
						for (m = 0; m < 3; m++)
							for (n = 0; n < 3; n++)
								dValue = dValue + H[m][n] * Value[m][n];
						dValue = dValue * K;
						//像素超限问题解决
						if (dValue > 255) dValue = 255;
						if (dValue < 0)   dValue = 0;
						pBits[lTotal + 0] = int(dValue + 0.5);

						//处理绿色通道
						/*Value[0][0] = pOldBits[lTotal - 3 * nWidth - 3 * 1 + 1];
						Value[0][1] = pOldBits[lTotal - 3 * nWidth - 3 * 0 + 1];
						Value[0][2] = pOldBits[lTotal - 3 * nWidth + 3 * 1 + 1];
						Value[1][0] = pOldBits[lTotal - 3 * 0 - 3 * 1 + 1];
						Value[1][1] = pOldBits[lTotal - 3 * 0 - 3 * 0 + 1];
						Value[1][2] = pOldBits[lTotal - 3 * 0 + 3 * 1 + 1];
						Value[2][0] = pOldBits[lTotal + 3 * nWidth - 3 * 1 + 1];
						Value[2][1] = pOldBits[lTotal + 3 * nWidth - 3 * 0 + 1];
						Value[2][2] = pOldBits[lTotal + 3 * nWidth + 3 * 1 + 1];*/
						Value[0][0] = pOldBits[lTotal - linebyte - 3 * 1 + 1];
						Value[0][1] = pOldBits[lTotal - linebyte - 3 * 0 + 1];
						Value[0][2] = pOldBits[lTotal - linebyte + 3 * 1 + 1];
						Value[1][0] = pOldBits[lTotal - 3 * 0 - 3 * 1 + 1];
						Value[1][1] = pOldBits[lTotal - 3 * 0 - 3 * 0 + 1];
						Value[1][2] = pOldBits[lTotal - 3 * 0 + 3 * 1 + 1];
						Value[2][0] = pOldBits[lTotal + linebyte - 3 * 1 + 1];
						Value[2][1] = pOldBits[lTotal + linebyte - 3 * 0 + 1];
						Value[2][2] = pOldBits[lTotal + linebyte + 3 * 1 + 1];
						dValue = 0.0;
						for (m = 0; m < 3; m++)
							for (n = 0; n < 3; n++)
								dValue = dValue + H[m][n] * Value[m][n];
						dValue = dValue * K;
						//像素超限问题解决
						if (dValue > 255) dValue = 255;
						if (dValue < 0)   dValue = 0;
						pBits[lTotal + 1] = int(dValue + 0.5);

						//处理红色通道
						/*Value[0][0] = pOldBits[lTotal - 3 * nWidth - 3 * 1 + 2];
						Value[0][1] = pOldBits[lTotal - 3 * nWidth - 3 * 0 + 2];
						Value[0][2] = pOldBits[lTotal - 3 * nWidth + 3 * 1 + 2];
						Value[1][0] = pOldBits[lTotal - 3 * 0 - 3 * 1 + 2];
						Value[1][1] = pOldBits[lTotal - 3 * 0 - 3 * 0 + 2];
						Value[1][2] = pOldBits[lTotal - 3 * 0 + 3 * 1 + 2];
						Value[2][0] = pOldBits[lTotal + 3 * nWidth - 3 * 1 + 2];
						Value[2][1] = pOldBits[lTotal + 3 * nWidth - 3 * 0 + 2];
						Value[2][2] = pOldBits[lTotal + 3 * nWidth + 3 * 1 + 2];*/
						Value[0][0] = pOldBits[lTotal - linebyte - 3 * 1 + 2];
						Value[0][1] = pOldBits[lTotal - linebyte - 3 * 0 + 2];
						Value[0][2] = pOldBits[lTotal - linebyte + 3 * 1 + 2];
						Value[1][0] = pOldBits[lTotal - 3 * 0 - 3 * 1 + 2];
						Value[1][1] = pOldBits[lTotal - 3 * 0 - 3 * 0 + 2];
						Value[1][2] = pOldBits[lTotal - 3 * 0 + 3 * 1 + 2];
						Value[2][0] = pOldBits[lTotal + linebyte - 3 * 1 + 2];
						Value[2][1] = pOldBits[lTotal + linebyte - 3 * 0 + 2];
						Value[2][2] = pOldBits[lTotal + linebyte + 3 * 1 + 2];
						dValue = 0.0;
						for (m = 0; m < 3; m++)
							for (n = 0; n < 3; n++)
								dValue = dValue + H[m][n] * Value[m][n];
						dValue = dValue * K;
						//像素超限问题解决
						if (dValue > 255) dValue = 255;
						if (dValue < 0)   dValue = 0;
						pBits[lTotal + 2] = int(dValue + 0.5);
					}
				}
			}
			Invalidate();
			delete pOldBits;
		}
	}
}


void CQQFImage1View::OnFsbh()
{
	JHBHDlg jhbh_1;       //新建一个仿射变换的对话框
	if (jhbh_1.DoModal())
	{
		Point2f srcTri[3];     //定义仿射变换源三角形
		Point2f dstTri[3];     //定义仿射变换目标三角形
		Mat rot_mat(2, 3, CV_32FC1);       //定义旋转矩阵
		Mat warp_mat(2, 3, CV_32FC1);      //定义仿射变换的矩阵
		Mat warp_dst, warp_rotate_dst;     //仿射变换后的图片，和仿射加旋转的图片
		CQQFImage1Doc* pDoc = GetDocument();     //获取图窗的信息指针
		CString cpath = pDoc->GetPathName();     //将路径转化为CString
		string path = CT2A(cpath.GetBuffer());   //将路径转化为string
		Mat src = imread(path, 0);        //用OpenCV读取该图像
		warp_dst = Mat::zeros(src.rows, src.cols, src.type());     //创建一个与原图像大小相同的图像
		//定义源三角形的三个顶点
		srcTri[0] = Point2f(0, 0);      
		srcTri[1] = Point2f(src.cols-1, 0);
		srcTri[2] = Point2f(0, src.rows-1);
		//定义目标三角形的三个顶点
		dstTri[0] = Point2f(src.cols*0.0, src.rows*0.33);
		dstTri[1] = Point2f(src.cols * 0.85, src.rows * 0.25);
		dstTri[2] = Point2f(src.cols * 0.15, src.rows * 0.7);
		//获取仿射变换矩阵
		warp_mat = getAffineTransform(srcTri, dstTri);
		warpAffine(src, warp_dst, warp_mat, warp_dst.size());    //进行仿射变换
		Point center = Point(warp_dst.cols / 2, warp_dst.rows / 2);      //变换中心
		double angle = jhbh_1.m_rotatedegree;  //旋转角度
		double scale = jhbh_1.m_scale;    //缩放比例
		rot_mat = getRotationMatrix2D(center, angle, scale);    //获取旋转矩阵
		warpAffine(warp_dst, warp_rotate_dst, rot_mat, warp_dst.size());    //进行旋转
		//显示图像
		namedWindow("原文件", CV_WINDOW_AUTOSIZE);
		imshow("原文件",src);
		namedWindow("仿射变换", CV_WINDOW_AUTOSIZE);
		imshow("仿射变换",warp_dst);
	    namedWindow("仿射变换+缩放",CV_WINDOW_AUTOSIZE);
		imshow("仿射变换+缩放", warp_rotate_dst);
		waitKey(0);
		
	}
}


void CQQFImage1View::OnFreqFour()
{
	CQQFImage1Doc* pDoc = GetDocument();     //获取当前图窗的指针
	CString cpath = pDoc->GetPathName();     //获取图窗打开图像的地址
	string path = CT2A(cpath.GetBuffer());   //转化为OpenCV可以识别的数据类型
	Mat I = imread(path, IMREAD_GRAYSCALE);  //读取为灰度图像
	Mat padded;    //用0填充输入图像矩阵
	//将图像大小转化为适合傅里叶变换的大小
	int m = getOptimalDFTSize(I.rows);      //图像的行数
	int n = getOptimalDFTSize(I.cols);      //图像的列数
	//利用0填充图像，扩展图像到最优的傅里叶变换大小
	copyMakeBorder(I, padded, 0, m - I.rows, 0, n - I.cols,BORDER_CONSTANT,Scalar::all(0) );
	Mat planes[] = { Mat_<float>(padded), Mat::zeros(padded.size(), CV_32F) };    //复数矩阵，包括实部和虚部
	Mat complexI;   //定义复数图像
	merge(planes, 2, complexI);        //planes和complexI融合
	dft(complexI, complexI);     //对complexI进行离散傅里叶变换
	split(complexI, planes);     //将complexI和planes分离
	magnitude(planes[0], planes[1], planes[0]);     //计算幅值，将数据存储在planes[0]
	Mat magI = planes[0];
	magI += Scalar::all(1);
	log(magI, magI);//转换到对数尺度(1ogarithmic scale)
	//如果有奇数行或列，则对频谱进行裁剪
	magI = magI(Rect(0, 0, magI.cols & -2, magI.rows & -2));//对奇数行或技术列裁剪
	//重新排列傅里叶图像中的象限，使得原点位于图像中心
	int cx = magI.cols / 2;
	int cy = magI.rows / 2;
	//分割图像
	Mat q0(magI, Rect(0, 0, cx, cy));    //左上
	Mat q1(magI, Rect(cx, 0, cx, cy));   //右上
	Mat q2(magI, Rect(0, cy, cx, cy));   //左下
	Mat q3(magI, Rect(cx, cy, cx, cy));  //右下
	//变换左上角和右下角象限
	Mat tmp;
	q0.copyTo(tmp);
	q3.copyTo(q0);
	tmp.copyTo(q3);
	//变换右上角和左下角象限
	q1.copyTo(tmp);
	q2.copyTo(q1);
	tmp.copyTo(q2);
	//归一化处理，用0-1之间的浮点数将矩阵变换
	normalize(magI, magI, 0, 1, CV_MINMAX);
	imshow("输入图像",I);
	imshow("频谐图", magI);
}


void CQQFImage1View::OnButterworthLow()
{
	CQQFImage1Doc* pDoc = GetDocument();      //获取当前图窗指针
	CString cpath = pDoc->GetPathName();      //获取图像路径，转换到imread可以接收的string类型
	string path = CT2A(cpath.GetBuffer());
	Mat img = imread(path, 0);    //以灰度图方式读取
	imshow("初始图像", img);
	Mat dftInputl, dftImagel, inverseDFT, inverseDFTconverted;    //定义傅里叶变换相关变量
	img.convertTo(dftInputl, CV_32F);     //将图像转换为浮点型
	dft(dftInputl, dftImagel);     //进行傅里叶变换
	imshow("傅里叶转换", dftImagel);
	//将傅里叶变换结果的象限进行交换，将原点移动到图像中心
	int cx = dftImagel.cols / 2;
	int cy = dftImagel.rows / 2;
	Mat q0(dftImagel, Rect(0, 0, cx, cy));    //左上
	Mat q1(dftImagel, Rect(cx, 0, cx, cy));   //右上
	Mat q2(dftImagel, Rect(0, cy, cx, cy));   //左下
	Mat q3(dftImagel, Rect(cx, cy, cx, cy));  //右下
	Mat tmp;
	q0.copyTo(tmp);    //交换q0和q3
	q3.copyTo(q0);     
	tmp.copyTo(q3);
	q1.copyTo(tmp);    //交换q1和q2
	q2.copyTo(q1);
	tmp.copyTo(q2);
	imshow("象限转换后", dftImagel);
	//计算图像的巴特沃斯低通滤波器
	//Scalar s0 = sum(dftImagel);
	int m = dftImagel.rows;
	int n = dftImagel.cols;
	Mat ButterLow(m, n, CV_32F);
	float DO = 100;      //截至频率
	double p = 5;     //巴特沃斯滤波器的阶数
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			//计算每个像素点到图像中心距离
			double d = sqrt(pow((i - m / 2), 2) + pow((j - n / 2), 2));
			float mm = d / DO;
			//计算巴特沃斯滤波器的值
			double nn = 1 + pow(mm, 2 * p);
			ButterLow.at<float>(i, j) = 1 / nn;
		}
	}
	multiply(dftImagel, ButterLow, ButterLow);    //将滤波器应用到傅里叶变换结果
	//将象限重新交换回来
	int cxl = ButterLow.cols / 2;
	int cyl = ButterLow.rows / 2;
	Mat r0(ButterLow, Rect(0, 0, cxl, cyl));	 //左上
	Mat r1(ButterLow, Rect(cxl, 0, cxl, cyl));   //右上
	Mat r2(ButterLow, Rect(0, cyl, cxl, cyl));   //左下
	Mat r3(ButterLow, Rect(cxl, cyl, cxl, cyl)); //右下
	Mat tmpl;
	r0.copyTo(tmpl);   //交换r0和r3
	r3.copyTo(r0);
	tmpl.copyTo(r3);
	r1.copyTo(tmpl);   //交换r1和r2
	r2.copyTo(r1);
	tmpl.copyTo(r2);
	imshow("巴特沃斯低通滤波器", ButterLow);   //显示滤波后频域结果
	idft(ButterLow, inverseDFT, DFT_SCALE | DFT_REAL_OUTPUT);  //进行逆傅里叶变换
	inverseDFT.convertTo(inverseDFTconverted, CV_8U);    //转换为8位无符号的整型
	//Scalar s1 = sum(ButterLow);
	imshow("Output", inverseDFTconverted);   //显示最终的图像
}


void CQQFImage1View::OnButterworthHigh()
{
    CQQFImage1Doc * pDoc = GetDocument();     //获取当前图窗的指针
	CString cpath = pDoc->GetPathName();    //转换图像路径到String
	string path = CT2A(cpath.GetBuffer());
	Mat img = imread(path, 0);   //以灰度的形式读取并显示
	imshow("初始图像", img);
	Mat dftInputl, dftImagel, inverseDFT, inverseDFTconverted;    //定义傅里叶变换的相关变量
	img.convertTo(dftInputl, CV_32F);    //将图像转换为浮点型
	dft(dftInputl, dftImagel);     //进行傅里叶变换
	imshow("傅里叶转换", dftImagel);
	//将傅里叶变换的结果的象限进行交换，以将原点移动到图像中心
	int cx = dftImagel.cols / 2;
	int cy = dftImagel.rows / 2;
	Mat q0(dftImagel, Rect(0, 0, cx, cy));    //左上
	Mat q1(dftImagel, Rect(cx, 0, cx, cy));   //右上
	Mat q2(dftImagel, Rect(0, cy, cx, cy));   //左下
	Mat q3(dftImagel, Rect(cx, cy, cx, cy));  //右下
	Mat tmp;
	q0.copyTo(tmp);    //交换q0和q3
	q3.copyTo(q0);
	tmp.copyTo(q3);
	q1.copyTo(tmp);    //交换q1和q2
	q2.copyTo(q1);
	tmp.copyTo(q2);
	imshow("象限转换后", dftImagel);

	//Scalar s0 = sum(dftImagel);
	//计算图像的巴特沃斯高通滤波器
	int m = dftImagel.rows;
	int n = dftImagel.cols;
	Mat ButterHigh(m, n, CV_32F);     //转化为浮点型
	float DO = 50;     //截至频率
	double p = 2;      //巴特沃斯滤波器的阶数
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			//计算每个像素点到图像中心的距离
			double d = sqrt(pow((i - m / 2), 2) + pow((j - n / 2), 2));
			float mm = DO/d;
			//计算巴特沃斯高通滤波器的值
			double nn = 1 + pow(mm, 2 * p);
			ButterHigh.at<float>(i, j) = 1 / nn;
		}
	}
	multiply(dftImagel, ButterHigh, ButterHigh);   //将滤波器应用到傅里叶变换的结果当中
	//重新交换象限
	int cxl = ButterHigh.cols / 2;
	int cyl = ButterHigh.rows / 2;
	Mat r0(ButterHigh, Rect(0, 0, cxl, cyl));
	Mat r1(ButterHigh, Rect(cxl, 0, cxl, cyl));
	Mat r2(ButterHigh, Rect(0, cyl, cxl, cyl));
	Mat r3(ButterHigh, Rect(cxl, cyl, cxl, cyl));
	Mat tmpl;
	r0.copyTo(tmpl);  //交换r0和r3
	r3.copyTo(r0);
	tmpl.copyTo(r3);
	r1.copyTo(tmpl);  //交换r1和r2
	r2.copyTo(r1);
	tmpl.copyTo(r2);
	imshow("巴特沃斯高通滤波器", ButterHigh);   //显示滤波后的频域图像
	idft(ButterHigh, inverseDFT, DFT_SCALE | DFT_REAL_OUTPUT);   //进行傅里叶逆变换
	inverseDFT.convertTo(inverseDFTconverted, CV_8U);   //转换为8位无符号的整型
	//Scalar s1 = sum(ButterHigh);
	imshow("Output", inverseDFTconverted);  //显示变换完成后的图像
}


void CQQFImage1View::OnOstuSegmentation()
{
	CQQFImage1Doc* pDoc = GetDocument();      //获取当前图窗的指针
	ASSERT_VALID(pDoc);
	unsigned char* pBits = pDoc->m_pBits;   //获取图窗显示图像的指针
	if (!pBits)
		return;
	int nWidth = pDoc->imageWidth;        //图像的宽度
	int nHeight = pDoc->imageHeight;      //图像的高度
	int nColorBits = pDoc->m_nColorBits;     //获取图像的颜色位数
	if (nColorBits != 8)    
	{
		//如果图像不是灰度图或者单通道的图，弹出消息框并终止进程
		MessageBox(_T("只支持8位位图的变换!"), _T("系统提示"), MB_ICONINFORMATION | MB_OK);
		return;
	}
	int nValue = 0;      //初始化灰度值
	//初始化灰度频数和直方图数组
	long lTotal = 0;
	long lTotalD = 0;
	long lTotalL = 0;
	dMax = 0;
	if (pDoc->m_nColorBits == 8)    //灰度图像
	{
		for (int k = 0; k < 256; k++)
		{
			m_lValue[k] = 0;       //初始化灰度值
			m_dValue[k] = 0.0;      //初始化灰度概率
		}
		for (int i = 0; i < nHeight; i++)
		{
			lTotalL = nWidth * i;      //当前行的起始位置
			for (int j = 0; j < nWidth; j++)
			{
				lTotalD = lTotalL + j;       //当前像素的位置
				nValue = *(pBits + lTotalD);     //获取灰度值
				m_lValue[nValue] = m_lValue[nValue] + 1;    //该灰度值数量加1 
			}
		}
		lTotal = nWidth * nHeight;        //总的像素值
		for (int k = 0; k < 256; k++)
		{
			m_dValue[k] = 1.0 * m_lValue[k] / lTotal;       //计算概率
			if (dMax < m_dValue[k])dMax = m_dValue[k];        //更新最大值
		}
	}
	int sp = 0;
	int mp = 255;
	//概率不为0的最小灰度等级 
	for (int i = 0; i < 255; ++i)
	{
		if (m_lValue[i] != 0)
		{
			sp = i;
			break;
		}
	}
	//概率不为0的最大灰度等级 
	for (int i = 255; i > 0; --i)
	{
		if (m_lValue[i] != 0)
		{
			mp = i;
			break;
		}
	}
	double ip1, ip2, is1, is2 = 0; //存储前景和背景的灰度总和及像素个数 
	double w0 = 0, w1 = 0; //前景和背景像素的比例 
	double mean1 = 0, mean2 = 0; //前景和背景的平均灰度 
	double g[256] = { 0.0 }; //存储类间方差 
	double gmax = 0; //最大类间方差 
	unsigned char th = 0; //二值化阈值

	for (int t = sp; t <= mp; ++t)
	{
		w0 = 0; w1 = 0;
		is1 = 0; is2 = 0;
		for (int i = sp; i <= t; ++i)
		{
			w0 += m_dValue[i];      //前景概率
			is1 += i * m_dValue[i];   //前景求和
		}
		for (int i = t+1 ; i <= mp; ++i)
		{
			w1 += m_dValue[i];     //背景概率
			is2 += i * m_dValue[i];    //背景求和
		}
		mean1 = is1 / w0;    //计算前景均值
		mean2 = is2 / w1;    //计算背景均值
		g[t] = w0 * w1 * (mean1 - mean2)*(mean1-mean2);     //类间方差化简后的表达式
		if (g[t] > gmax)
		{
			gmax = g[t];
			th = t;          //获取当类间方差最大的时候的灰度值作为阈值
		}
	}

	for (int i = 0; i < nHeight; i++)
	{
		lTotalL = nWidth * i;
		for (int j = 0; j < nWidth; j++)
		{
			lTotalD = lTotalL + j;
			*(pBits + lTotalD) = *(pBits + lTotalD) > th ? 255 : 0;    //使用阈值进行二值化处理
			
		}
	}
	//输出分割的阈值提示
	CString str;
	str.Format(_T("阈值% d!"), th);
	MessageBox(str, _T("系统提示"), MB_ICONINFORMATION | MB_OK);
	
	Invalidate();
	// 设置脏标记 
	pDoc->SetModifiedFlag(TRUE);
	// 更新视图 
	pDoc->UpdateAllViews(NULL);
	// 恢复光标 
	EndWaitCursor();
}


void CQQFImage1View::OnRegionGrowing()
{
	CQQFImage1Doc* pDoc = GetDocument();   //获取当前图窗的指针
	ASSERT_VALID(pDoc);
	if (!(pDoc->image)) return;
	pDoc->m_pBits = (unsigned char*)pDoc->image->imageData;   //获取图像数据指针
	unsigned char* pBits = pDoc->m_pBits;
	if (!pBits) return;
	pDoc->m_nColorBits = pDoc->image->nChannels * pDoc->image->depth;  //获取图像的位深度
	std::vector<int*>pData;  //创建pData向量，用于存储每个像素的像素值
	int nWidth = pDoc->imageWidth;   //获取图像的宽度
	int nHeight = pDoc->imageHeight; //获取图像的高度
	int nColorBits = pDoc->m_nColorBits;   //获取图像的颜色位数
	if (nColorBits == 8)   //灰度图
	{
		// 提示用户
		MessageBox(_T("只支持24位彩色图像的区域增长!"), _T("系统提示"), MB_ICONINFORMATION | MB_OK);
		return;
	}
	else if (nColorBits == 24)  //24位真彩色图像
	{
		int linebyte = pDoc->image->widthStep;
		pData.resize(3);   //分配了3个通道，分别存储R、G、B
		for (int k = 0; k < 3; k++)
		{
			pData[k] = new int[nWidth *  nHeight];   //每一个通道的大小都是图片的大小
		}
		for (int i = 0; i < nHeight; i++)
		{
			int lTotalL = i * linebyte;
			for (int j = 0; j < nWidth; j++)
			{
				//获取在（i，j）点处的像素值
				int lTotalD = lTotalL + j * 3;
				int idx = i * nWidth + j;
				pData[0][idx] = pBits[lTotalD];
				pData[1][idx] = pBits[lTotalD + 1];
				pData[2][idx] = pBits[lTotalD + 2];
			}
		}
	}
	ImageRegions regions;
	//调用区域增长的函数，对图像进行分割
	if (RegionGrowingSegmentation(pData, nWidth, nHeight, 200, regions))
	{
		//提示分割出的区域个数
		CString str;
		str.Format(_T("分割出 % d个区域!"), regions.size());
		MessageBox(str, _T("系统提示"), MB_ICONINFORMATION | MB_OK);
		// 设置脏标记
		pDoc->SetModifiedFlag(TRUE);
		// 更新视图
		pDoc->UpdateAllViews(NULL);
	}
	else
	{
		//提示用户分割失败
		MessageBox(_T("分割失败!"), _T("系统提示"), MB_ICONINFORMATION | MB_OK);
		return;
	}
	int b, g, r;
	int linebyte = pDoc->image->widthStep;
	for (::ImageRegions::iterator it = regions.begin(); it != regions.end(); ++it)
	{
		double r=0, g=0, b = 0;
		//计算每一个区域的平均像素值
		for (int i = 0; i < it->m_points.size(); ++i)
		{
			int x = (*it).m_points.at(i).m_x;
			int y = (*it).m_points.at(i).m_y;
			int idx = y * linebyte + x * 3;
			b+=pDoc->m_pBits[idx];
			g+=pDoc->m_pBits[idx + 1];
			r+=pDoc->m_pBits[idx + 2];
		}
		r = r / it->m_points.size(); b = b / it->m_points.size(); g = g / it->m_points.size();
		int R = (int)r; int G = (int)g; int B = (int)b;
		//为该区域像素点赋值，RGB都是该区域的平均值
		for (int i = 0; i < it->m_points.size(); ++i)
		{
			int x = (*it).m_points.at(i).m_x;
			int y = (*it).m_points.at(i).m_y;
			int idx = y * linebyte + x * 3;
			pDoc->m_pBits[idx] = B;
			pDoc->m_pBits[idx + 1] = G;
			pDoc->m_pBits[idx + 2] = R;
		}
	}
	EndWaitCursor();  //恢复光标
}




//改进代码
Mat result;
int param2 = 26;
int on_trackbar(Mat image, Mat edges)
{
	
	vector<Vec3f> circles;
	HoughCircles(edges, circles, HOUGH_GRADIENT, 1.206, 10, 13, param2, 1, 50);

	for (const auto& circle : circles)
	{
		Point center(cvRound(circle[0]), cvRound(circle[1]));
		int radius = cvRound(circle[2]);
		cv::circle(result, center, radius, Scalar(255, 0, 0), 4);
		rectangle(result, cv::Point(center.x - 5, center.y - 5), Point(center.x + 5, center.y + 5), Scalar(0, 128, 255), -1);
	}
	imshow("边缘显现", result);
	return circles.size();
}
void CQQFImage1View::OnImageEx()
{

	KaoheDlg dlg1;    //创建对话框对象
	CQQFImage1Doc* pDoc = GetDocument();    //获取当前图窗的指针
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	CString cpath = pDoc->GetPathName();    //获取图像的路径，转换为CString类型
	string path = CT2A(cpath.GetBuffer());
	Mat image = imread(path, 0);
	GaussianBlur(image, image, cv::Size(3, 3), 0);     //进行高斯平滑
	Mat edges;
	Canny(image, edges, 70, 140);        //使用Canny算子处理，提取轮廓
	result = image.clone();
	namedWindow("边缘显现", WINDOW_AUTOSIZE);
	// 创建滑动条
	createTrackbar("param2", "边缘显现", &param2, 150);
	dlg1.number = on_trackbar(image, edges); // 初始化显示结果

	//vector<Vec3f> circles;    //定义圆形，三个值确定一个圆（x，y，半径）
	//HoughCircles(edges, circles, HOUGH_GRADIENT, 1.206, 10, 13, 26, 1, 50);      //利用Hough变换提取圆形轮廓
	//if (!circles.empty())
	//{
	//	for (const auto& circle : circles)    //遍历circles中的圆形
	//	{
	//		Point center(cvRound(circle[0]), cvRound(circle[1]));  //圆心位于（x，y）
	//		int radius = cvRound(circle[2]);   //半径
	//		cv::circle(image, center, radius, Scalar(255, 0, 0), 4);   // 在图像上绘制检测到的圆 
	//		rectangle(image, cv::Point(center.x - 5, center.y - 5),  //在圆心处绘制一个矩形标记，突出显示
	//		Point(center.x + 5, center.y + 5), Scalar(0, 128, 255), -1);
	//		dlg1.number = circles.size();   //将检测到的圆形数量赋值给对话框的number属性
	//	}
	//}
	vector<vector<Point>> contours;  //定义点的集合，用于存储轮廓信息
	findContours(edges, contours, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);   //寻找轮廓
	for (const auto& contour : contours)
	{
		vector<Point> approx;
		approxPolyDP(contour, approx, arcLength(contour, true) * 0.02, true);  //逼近多边形曲线
		if (approx.size() == 4)   //如果被逼近的多边形有四个顶点
		{
			RotatedRect minRect = cv::minAreaRect(contour);  //寻找最小外接矩形
			Point2f rect_points[4];    //边界的四个顶点
			minRect.points(rect_points);
			for (int j = 0; j < 4; j++) 
			{
				line(image, rect_points[j], rect_points[(j + 1) % 4], Scalar(0, 255, 0), 2);
			}
			float a= norm(rect_points[0] - rect_points[1]);    //求边长
			float b = norm(rect_points[1] - rect_points[2]);
			if (a > b) { dlg1.length = a; dlg1.width = b; }   //将长边定义为长
			else { dlg1.length = b; dlg1.width = a; }   //短边为宽
		}
	}
	imshow("Canny边缘", edges);
	//imshow("边缘显现", image);
	dlg1.DoModal();    //显示对话框
	waitKey(0);
}
