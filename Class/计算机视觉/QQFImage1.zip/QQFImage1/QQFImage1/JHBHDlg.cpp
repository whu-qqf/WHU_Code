﻿// JHBHDlg.cpp: 实现文件
//

#include "pch.h"
#include "QQFImage1.h"
#include "afxdialogex.h"
#include "JHBHDlg.h"


// JHBHDlg 对话框

IMPLEMENT_DYNAMIC(JHBHDlg, CDialog)

JHBHDlg::JHBHDlg(CWnd* pParent /*=nullptr*/)
	: CDialog(IDD_DIALOG_JHBH, pParent)
	, m_scale(0)
	, m_rotatedegree(0)
{
	m_scale = 0.6f;
	m_rotatedegree = 60;
}

JHBHDlg::~JHBHDlg()
{
}

void JHBHDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_SCALE, m_scale);
	DDX_Text(pDX, IDC_TURN, m_rotatedegree);
}


BEGIN_MESSAGE_MAP(JHBHDlg, CDialog)
END_MESSAGE_MAP()


// JHBHDlg 消息处理程序
