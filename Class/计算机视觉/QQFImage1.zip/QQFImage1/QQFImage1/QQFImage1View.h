﻿
// QQFImage1View.h: CQQFImage1View 类的接口
//

#pragma once


class CQQFImage1View : public CScrollView
{
protected: // 仅从序列化创建
	CQQFImage1View() noexcept;
	DECLARE_DYNCREATE(CQQFImage1View)

// 特性
public:
	CQQFImage1Doc* GetDocument() const;
	double m_dZoom;

// 操作
public:
	void DrawGraph(CDC* pDC);//绘制直方图函数
	long m_lValue[256];//红色分量灰度统计
	double m_dValue[256];// 红色分量灰度频数
	long m_lValueG[256]; //绿色分量灰度统计
	double m_dValueG[256]; // 绿色分量灰度频数
	long m_lValueB[256]; //蓝色分量灰度统计
	double m_dValueB[256]; //蓝色分量灰度频数
	double dMax, dMaxG, dMaxB;//红、绿、蓝频数最大值
	BOOL m_bShow;//是否显示直方图

// 重写
public:
	virtual void OnDraw(CDC* pDC);  // 重写以绘制该视图
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual void OnInitialUpdate(); // 构造后第一次调用
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// 实现
public:
	virtual ~CQQFImage1View();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// 生成的消息映射函数
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnViewZoomOut();
	afx_msg void OnViewZoomIn();
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnOpencv1();
	afx_msg void OnProcessLinetran();
	afx_msg void OnProcessZhifangtu();
	afx_msg void OnDrawgraph();
	afx_msg void OnImageSmooth();
	afx_msg void OnFsbh();
	afx_msg void OnFreqFour();
	afx_msg void OnButterworthLow();
	afx_msg void OnButterworthHigh();
	afx_msg void OnOstuSegmentation();
	afx_msg void OnRegionGrowing();
	afx_msg void OnImageEx();
};

#ifndef _DEBUG  // QQFImage1View.cpp 中的调试版本
inline CQQFImage1Doc* CQQFImage1View::GetDocument() const
   { return reinterpret_cast<CQQFImage1Doc*>(m_pDocument); }
#endif

