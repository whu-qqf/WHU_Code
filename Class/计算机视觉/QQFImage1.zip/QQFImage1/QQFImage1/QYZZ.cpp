﻿#include"pch.h"
#include<vector>
#include"QYZZ.h"
#include<queue>
#include<cmath>

int RegionGrowingSegmentation(std::vector<int*>pData, int imageWidth, int imageHeight, int threshold, ImageRegions& regions)
{
	if (!pData.size())return 0;    //检查数据是否为空
	long lTotal = imageWidth * imageHeight;   //图像的大小
	int* pR = pData[0];   //存储R值
	int* pG = pData[1];   //存储G值
	int* pB = pData[2];   //存储B值
	//初始化标记矩阵，所有的像素都标记为1。表示未曾访问过
	std::vector<int>label(lTotal);
	for (int i = 0; i < lTotal; i++)
	{
		label[i] = 1;
	}
	//定义搜索的方向：上下左右
	int direction[4][2] = { {0,-1},{-1,0},{0,1},{1,0} };
	int regionnum = 0;//初始化分割区域的数量
	//遍历图像的每个像素
	for (int j = 0; j < imageHeight; j++)
	{
		for (int i = 0; i < imageWidth; i++)
		{
			int idx = i + j * imageWidth;
			if (label[idx] == 1)   //如果当前像素没有被访问过
			{
				ImageRegion newobj;  //定义一个新的区域
				newobj.m_id = regionnum;   //id
				ImagePoint pt(i, j);   //在这个区域里面的一个点
				newobj.m_points.push_back(pt);  //加入到区域里面
				newobj.m_ul = pt;
				newobj.m_lr = pt;
				label[idx] = 0;   //改变标记，表示已经访问过该点
				std::queue<ImagePoint>seed;   //一块区域的序列集合 
				seed.push(pt);  //区域的起始点
				//进行区域增长
				while (seed.size())
				{
					ImagePoint tmpseed = seed.front();
					seed.pop();
					for (int k = 0; k < 4; k++)
					{
						int x = tmpseed.m_x + direction[k][0];
						int y = tmpseed.m_y + direction[k][1];
						//检查邻域像素是否在图像范围内
						if (x < 0 || x >= imageWidth || y < 0 || y >= imageHeight) continue;
						int xyidx = x + y * imageWidth;
						//计算当前像素与领域像素的颜色差异
						int diff = std::abs(pR[idx] - pR[xyidx]) + std::abs(pG[idx] - pG[xyidx]) + std::abs(pB[idx] - pB[xyidx]);
						//如果该像素为被访问且像素值差异在阈值内
						if ((label[xyidx] == 1) && (diff <= threshold))// 设置阈值
						{
							ImagePoint tmppt(x, y);
							newobj.m_points.push_back(tmppt);  //把点加入到这个区域里面
							label[xyidx] = 0;   //改变标记，表示已经访问过这个点
							//扩展区域的边界
							if (newobj.m_ul.m_x > tmppt.m_x) newobj.m_ul.m_x = tmppt.m_x;
							if (newobj.m_ul.m_y > tmppt.m_y) newobj.m_ul.m_y = tmppt.m_y;
							if (newobj.m_ul.m_x < tmppt.m_x) newobj.m_ul.m_x = tmppt.m_x;
							if (newobj.m_ul.m_y < tmppt.m_y) newobj.m_ul.m_y = tmppt.m_y;
							seed.push(tmppt);  //加入这个点
						}
					}
				}
				regions.push_back(newobj);   //将区域加入到区域集合
				regionnum++;   //区域id加一
			}
		}
	}
	return regionnum;    //返回图片的区域增长分割的区域数量

}