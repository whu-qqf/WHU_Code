﻿// KaoheDlg.cpp: 实现文件
//

#include "pch.h"
#include "QQFImage1.h"
#include "afxdialogex.h"
#include "KaoheDlg.h"


// KaoheDlg 对话框

IMPLEMENT_DYNAMIC(KaoheDlg, CDialog)

KaoheDlg::KaoheDlg(CWnd* pParent /*=nullptr*/)
	: CDialog(IDD_DIALOG_KAOHE, pParent)
	, number(0)
	, length(0)
	, width(0)
{

}

KaoheDlg::~KaoheDlg()
{
}

void KaoheDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//  DDX_Text(pDX, IDC_EDIT1, number);
	DDX_Text(pDX, IDC_EDIT2, length);
	DDX_Text(pDX, IDC_EDIT1, number);
	DDX_Text(pDX, IDC_EDIT3, width);
}


BEGIN_MESSAGE_MAP(KaoheDlg, CDialog)
END_MESSAGE_MAP()


// KaoheDlg 消息处理程序
