﻿
// QQFImage1Doc.cpp: CQQFImage1Doc 类的实现
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS 可以在实现预览、缩略图和搜索筛选器句柄的
// ATL 项目中进行定义，并允许与该项目共享文档代码。
#ifndef SHARED_HANDLERS
#include "QQFImage1.h"
#endif

#include "QQFImage1Doc.h"

#include <propkey.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CQQFImage1Doc

IMPLEMENT_DYNCREATE(CQQFImage1Doc, CDocument)

BEGIN_MESSAGE_MAP(CQQFImage1Doc, CDocument)
END_MESSAGE_MAP()


// CQQFImage1Doc 构造/析构

CQQFImage1Doc::CQQFImage1Doc() noexcept
{
	// TODO: 在此添加一次性构造代码
	m_pBits = NULL;
	lpbmi = NULL;
	imageWidth = 768;
	imageHeight = 576;
	m_nOpenMode = 0;
	m_nColorBits = 8;

	image = NULL;

}

CQQFImage1Doc::~CQQFImage1Doc()
{
}

BOOL CQQFImage1Doc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: 在此添加重新初始化代码
	// (SDI 文档将重用该文档)

	return TRUE;
}




// CQQFImage1Doc 序列化

void CQQFImage1Doc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: 在此添加存储代码
	}
	else
	{
		// TODO: 在此添加加载代码
	}
}

#ifdef SHARED_HANDLERS

// 缩略图的支持
void CQQFImage1Doc::OnDrawThumbnail(CDC& dc, LPRECT lprcBounds)
{
	// 修改此代码以绘制文档数据
	dc.FillSolidRect(lprcBounds, RGB(255, 255, 255));

	CString strText = _T("TODO: implement thumbnail drawing here");
	LOGFONT lf;

	CFont* pDefaultGUIFont = CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT));
	pDefaultGUIFont->GetLogFont(&lf);
	lf.lfHeight = 36;

	CFont fontDraw;
	fontDraw.CreateFontIndirect(&lf);

	CFont* pOldFont = dc.SelectObject(&fontDraw);
	dc.DrawText(strText, lprcBounds, DT_CENTER | DT_WORDBREAK);
	dc.SelectObject(pOldFont);
}

// 搜索处理程序的支持
void CQQFImage1Doc::InitializeSearchContent()
{
	CString strSearchContent;
	// 从文档数据设置搜索内容。
	// 内容部分应由“;”分隔

	// 例如:     strSearchContent = _T("point;rectangle;circle;ole object;")；
	SetSearchContent(strSearchContent);
}

void CQQFImage1Doc::SetSearchContent(const CString& value)
{
	if (value.IsEmpty())
	{
		RemoveChunk(PKEY_Search_Contents.fmtid, PKEY_Search_Contents.pid);
	}
	else
	{
		CMFCFilterChunkValueImpl *pChunk = nullptr;
		ATLTRY(pChunk = new CMFCFilterChunkValueImpl);
		if (pChunk != nullptr)
		{
			pChunk->SetTextValue(PKEY_Search_Contents, value, CHUNK_TEXT);
			SetChunkValue(pChunk);
		}
	}
}

#endif // SHARED_HANDLERS

// CQQFImage1Doc 诊断

#ifdef _DEBUG
void CQQFImage1Doc::AssertValid() const
{
	CDocument::AssertValid();
}

void CQQFImage1Doc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// CQQFImage1Doc 命令
BOOL CQQFImage1Doc::ReadBMP(LPCTSTR lpszPathName)
{
	long lTotal = 0;  //初始化总像素变量
	CFile file;      //创建CFile对象，对象名为file
	file.Open(lpszPathName, CFile::modeRead);   //file以读的方式打开文件地址
	file.Read(&bmpFH, sizeof(BITMAPFILEHEADER));  //读取BMP的文件头信息BITMAPFILEHEADER
	lpbmi = (LPBITMAPINFO)new char[sizeof(BITMAPINFO) + 4 * (1 << 8)];  //为BITMAPINFO结构分配内存
	file.Read(lpbmi, sizeof(BITMAPINFOHEADER));   //读取BMP信息头信息

	//获取图像的位深度、高度、宽度
	m_nColorBits = lpbmi->bmiHeader.biBitCount;   //位深度
	imageHeight = lpbmi->bmiHeader.biHeight;    //高度
	imageWidth = lpbmi->bmiHeader.biWidth;    //宽度

	//根据位深度的不同读取文件
	if (m_nColorBits == 8)     //灰度图
	{
		lTotal = imageWidth * imageHeight;  //计算总像素
		file.Read(&(lpbmi->bmiColors[0]), 256 * 4);  //读取调色板信息
	}
	else if (m_nColorBits == 24)     //24位位图
	{
		lTotal = imageWidth * imageHeight * 3; //计算总像素
	}
	else       //其他图像不支持
	{
		file.Close();      //关闭file
		return FALSE;
	}
	m_pBits = new unsigned char[lTotal];  //分配内存存储数据
	file.Read(m_pBits, lTotal);  //读取像素信息
	file.Close();    //关闭file
	return TRUE;
}

BOOL CQQFImage1Doc::OnOpenDocument(LPCTSTR lpszPathName)
{
	if (!CDocument::OnOpenDocument(lpszPathName))
		return FALSE;
	CString str = lpszPathName;
	str.MakeLower();
	if (str.Find(_TEXT(".bmp")) != -1)
	{
		m_nOpenMode = 1;
		if (!ReadBMP(lpszPathName)) return FALSE;
	}

	if (str.Find(_TEXT(".jpg")) != -1)    //判断是否为JPG图像
	{
		m_nOpenMode = 2;    //设置打开模式为2
		image = cvLoadImage((CStringA)lpszPathName);    //利用OpenCV中cvLoadImage函数加载JPG图像
		m_pBits = (unsigned char*)image->imageData;    //将图像数据指针赋值给m_pBits
		imageHeight = image->height;  //高度
		imageWidth = image->width;   //宽度

		//根据通道数设置颜色位数
		if (image->nChannels == 1)
		{
			m_nColorBits = 8;
		}
		else if (image->nChannels == 3)
		{
			m_nColorBits = 24;
		}

		lpbmi = (LPBITMAPINFO)new char[sizeof(BITMAPINFO) + 4 * (1 << 8)];    //为BITMAPINFO结构分配内存
		lpbmi->bmiHeader.biBitCount = image->depth * image->nChannels;    //设置像素位数
		lpbmi->bmiHeader.biClrUsed = 0;    //使用的颜色数
		lpbmi->bmiHeader.biHeight = image->height;  //高度
		lpbmi->bmiHeader.biWidth = image->width;   //宽度
		lpbmi->bmiHeader.biSize = sizeof(BITMAPINFOHEADER);    //BITMAPINFOHEADER头信息文件大小
		lpbmi->bmiHeader.biSizeImage = image->width * image->height * image->nChannels;    //图像数据大小
		lpbmi->bmiHeader.biClrImportant = 0;    //重要颜色数，0表示都很重要
		lpbmi->bmiHeader.biCompression = 0;    //表示无压缩图像
		lpbmi->bmiHeader.biPlanes = 1;   //平面数，为1
		imageWidth = image->width;  //更新宽度
		imageHeight = image->height;  //更新高度
		for (int i = 0; i < (1 << 8); i++)
		{
			RGBQUAD& o = lpbmi->bmiColors[i];
			o.rgbBlue = i;
			o.rgbGreen = i;
			o.rgbRed = i;
			o.rgbReserved = 0;
		}
	}
	return TRUE;
}


BOOL CQQFImage1Doc::OnSaveDocument(LPCTSTR lpszPathName)
{
	// TODO: 在此添加专用代码和/或调用基类
	if (m_nOpenMode == 1 && m_pBits != NULL)SaveBMP(lpszPathName);

	if (m_nOpenMode == 2 && image != NULL)
	{
		cvSaveImage(CStringA(lpszPathName), image);
	}
	return TRUE;
	return CDocument::OnSaveDocument(lpszPathName);
}

BOOL CQQFImage1Doc::SaveBMP(LPCTSTR lpszPathName)
{
	long lTotal = 0;   //初始化图像数据大小
	CFile file;    //创建CFile对象，用于文件操作
	file.Open(lpszPathName, CFile::modeCreate | CFile::modeReadWrite);   //以写入方式打开
	file.Write(&bmpFH, sizeof(BITMAPFILEHEADER));    //写入BMP文件头
	file.Write(lpbmi, sizeof(BITMAPINFOHEADER));     //写入BMP信息头
	if (m_nColorBits == 8)     //灰度图
	{
		lTotal = imageWidth * imageHeight;
		file.Write(&(lpbmi->bmiColors[0]), 256 * 4);     //写入调色板信息
	}
	else if (m_nColorBits == 24)    //24位彩色图
	{
		lTotal = imageWidth * imageHeight * 3;     //计算彩色图像数据大小
	}
	else      //其他位深度不支持
	{
		file.Close();
		return FALSE;
	}

	file.Write(m_pBits, lTotal);
	file.Close();
	return TRUE;

}