﻿#pragma once
#include "afxdialogex.h"


// CHistogramDisply 对话框

class CHistogramDisply : public CDialogEx
{
	DECLARE_DYNAMIC(CHistogramDisply)

public:
	CHistogramDisply(CWnd* pParent = nullptr);   // 标准构造函数
	virtual ~CHistogramDisply();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG_HISTOGRAM };
#endif
public:
	double m_dValue[256];
	double m_dValueG[256];
	double m_dValueB[256];
	double dMax, dMaxG, dMaxB;
	int m_nColorBits;
	void DrawGraph(CDC* pDC);

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnPaint();
};
