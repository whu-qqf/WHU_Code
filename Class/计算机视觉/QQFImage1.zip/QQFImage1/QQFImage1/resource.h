﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 QQFImage1.rc 使用
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_QQFImage1TYPE               130
#define ID_WINDOW_MANAGER               131
#define IDD_DIALOG_HISTOGRAM            310
#define IDD_DIALOG_SMOOTH               312
#define IDD_DIALOG_JHBH                 314
#define IDD_DIALOG_KAOHE                316
#define IDC_EDIT1                       1002
#define IDC_EDIT2                       1003
#define IDC_EDIT4                       1004
#define IDC_EDIT5                       1005
#define IDC_EDIT6                       1006
#define IDC_EDIT7                       1007
#define IDC_EDIT8                       1008
#define IDC_EDIT9                       1009
#define IDC_EDIT10                      1010
#define IDC_EDIT3                       1011
#define IDC_TURN                        1012
#define IDC_SCALE                       1014
#define IDC_SCROLLBAR1                  1017
#define ID_32771                        32771
#define ID_32772                        32772
#define ID_32773                        32773
#define ID_IN_VIEW_ZOOM_OUT             32774
#define ID_VIEW_ZOOM_IN                 32775
#define ID_VIEW_ZOOM_OUT                32776
#define ID_OPENCV1                      32777
#define ID_OPENCV32778                  32778
#define ID_32779                        32779
#define ID_32780                        32780
#define ID_COIN_ADD                     32781
#define ID_COIN_SUB                     32782
#define ID_32783                        32783
#define ID_PROCESS_LINETRAN             32784
#define ID_32785                        32785
#define ID_PROCESS_ZHIFANGTU            32786
#define ID_32787                        32787
#define ID_DrawGraph                    32788
#define ID_32789                        32789
#define ID_IMAGE_SMOOTH                 32790
#define ID_32791                        32791
#define ID_KEEP                         32792
#define ID_32793                        32793
#define ID_FSBH                         32794
#define ID_32795                        32795
#define ID_32796                        32796
#define ID_FREQ_FOUR                    32797
#define ID_32798                        32798
#define ID_Menu                         32799
#define ID_32800                        32800
#define ID_BUTTERWORTH_LOW              32801
#define ID_BUTTERWORTH_HIGH             32802
#define ID_32803                        32803
#define ID_32804                        32804
#define ID_32805                        32805
#define ID_OSTU_SEGMENTATION            32806
#define ID_REGION_GROWING               32807
#define ID_Menu32808                    32808
#define ID_IMAGE_EX                     32809

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        318
#define _APS_NEXT_COMMAND_VALUE         32810
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
