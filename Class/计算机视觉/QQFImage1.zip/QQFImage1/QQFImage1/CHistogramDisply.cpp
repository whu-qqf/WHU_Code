﻿// CHistogramDisply.cpp: 实现文件
//

#include "pch.h"
#include "QQFImage1.h"
#include "afxdialogex.h"
#include "CHistogramDisply.h"


// CHistogramDisply 对话框

IMPLEMENT_DYNAMIC(CHistogramDisply, CDialogEx)

CHistogramDisply::CHistogramDisply(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG_HISTOGRAM, pParent)
{

}

CHistogramDisply::~CHistogramDisply()
{
}

void CHistogramDisply::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

void CHistogramDisply::DrawGraph(CDC* pDC)
{
	//定义绘图的起点和尺寸
	int X0 = 0 + 250;       //X轴起点
	int Y0 = 510;        //Y轴起点
	int WX = 768 + 3, HY = 500;     //绘图区域的宽度和高度
	int H = 375;    //直方图的高度
	int W = 256;    //直方图的宽度
	//绘制边框
	CPen cyPen(PS_SOLID, 2, RGB(255, 255, 0));
	CPen* oldPen = pDC->SelectObject(&cyPen);
	pDC->MoveTo(X0, Y0);
	pDC->LineTo(X0 + WX, Y0);   //底边
	pDC->MoveTo(X0, Y0);
	pDC->LineTo(X0, Y0 - HY);   //左边
	pDC->MoveTo(X0, Y0 - HY);
	pDC->LineTo(X0 + WX, Y0 - HY);   //顶边
	pDC->MoveTo(X0 + WX, Y0);
	pDC->LineTo(X0+WX, Y0 - HY);   //右边
	pDC->SelectObject(&oldPen);


	{
		CPen redPen(PS_SOLID, 1, RGB(255, 0, 0));   //红色画笔用于画R分量或灰度图的灰度
		oldPen = pDC->SelectObject(&redPen);
		for (int i = 0; i < 256; i++)
		{
			//绘制红色分量或灰度值
			int x0, y0, x1, y1;
			double dy;
			x0 = X0 + i * 3;
			y0 = Y0;
			x1 = X0 + i * 3;
			dy = Y0 - 1.0 * H * m_dValue[i] / dMax;
			y1 = int(dy + 0.5);
			pDC->MoveTo(x0, y0);
			pDC->LineTo(x1, y1);
		}
		pDC->SelectObject(oldPen);
	}
	if (m_nColorBits == 24)   //24位彩色图像
	{
		{
			CPen grnPen(PS_SOLID, 1, RGB(0, 255, 0));  //绿色分量
			oldPen=pDC->SelectObject(&grnPen);
			for (int i = 0; i < 256; i++)
			{
				int x0, y0, x1, y1;
				double dy;
				x0 = X0 + i * 3 + 1;
				y0 = Y0;
				x1 = X0 + i * 3 + 1;
				dy = Y0 - 1.0 * H * m_dValueG[i] / dMaxG;
				y1 = int(dy + 0.5);
				pDC->MoveTo(x0, y0);
				pDC->LineTo(x1, y1);
			}
			pDC->SelectObject(&grnPen);
		}
		{
			CPen grnPen(PS_SOLID, 1, RGB(0, 0, 255));  //蓝色分量
			oldPen = pDC->SelectObject(&grnPen);
			for (int i=0;i<256;i++)
			{
				int x0, y0, x1, y1;
				double dy;
				x0 = X0+ i * 3 + 2;
				y0 = Y0;
				x1 = X0 + i * 3 + 2;
				dy = Y0 - 1.0 * H * m_dValueB[i] / dMaxB;
				y1 = int(dy + 0.5);
				pDC->MoveTo(x0, y0);
				pDC->LineTo(x1, y1);
			}
			pDC->SelectObject(oldPen);
		}
	}

}

BEGIN_MESSAGE_MAP(CHistogramDisply, CDialogEx)
	ON_WM_PAINT()
END_MESSAGE_MAP()


// CHistogramDisply 消息处理程序


void CHistogramDisply::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	// TODO: 在此处添加消息处理程序代码
	// 不为绘图消息调用 CDialogEx::OnPaint()
	DrawGraph(&dc);
}
