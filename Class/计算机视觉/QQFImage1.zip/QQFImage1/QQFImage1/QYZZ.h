#pragma once
#include<vector>
#include<list>

struct ImagePoint
{
public:
	int m_x;
	int m_y;
	ImagePoint()
	{
		m_x = 0;
		m_y = 0;
	}
	ImagePoint(int x, int y)
	{
		m_x = x;
		m_y = y;
	}
};

typedef std::vector<ImagePoint> ImagePoints;

struct ImageRegion
{
public:
	int m_id;
	ImagePoints m_points;
	ImagePoint m_ul;
	ImagePoint m_lr;
};

typedef std::list<ImageRegion> ImageRegions;

int RegionGrowingSegmentation(std::vector<int*>pData, int imageWidth, int imageHeight, int threshold, ImageRegions& regions);

