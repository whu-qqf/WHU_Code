#include <ros/ros.h>
#include <actionlib/server/simple_action_server.h>
#include <tf2_ros/transform_listener.h>
#include<tf2/utils.h>
#include <geometry_msgs/Twist.h>
#include <geometry_msgs/PoseStamped.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>
#include "burger/TurtleBot3NavigateToGoalAction.h" 


class NavigationActionServer {
private:
    actionlib::SimpleActionServer<burger::TurtleBot3NavigateToGoalAction> action_server_;    //action的服务器
    tf2_ros::Buffer tf_buffer_;    // 用于存储坐标变换
    tf2_ros::TransformListener tf_listener_;    //用于监听坐标变换
    ros::Publisher vel_pub_;    // 发布速度指令
    geometry_msgs::PoseStamped target_pose_;    // 目标位置
   
public:
    NavigationActionServer(ros::NodeHandle* nh) : 
        action_server_(*nh, "navigate_to_goal", false),
        tf_listener_(tf_buffer_) {
        action_server_.registerGoalCallback(boost::bind(&NavigationActionServer::handleGoal, this));
        action_server_.start();
        vel_pub_ = nh->advertise<geometry_msgs::Twist>("cmd_vel", 10);
    }
    void handleGoal() {
        auto goal = action_server_.acceptNewGoal();
        target_pose_ = goal->target_pos;
        ROS_INFO("接收到新的坐标点: (%.2f, %.2f)", 
                target_pose_.pose.position.x, 
                target_pose_.pose.position.y);

        ros::Rate rate(10);
        while (ros::ok()) {
            geometry_msgs::TransformStamped transform;
            try {
                transform = tf_buffer_.lookupTransform("odom", "base_footprint", ros::Time(0));
            } catch (tf2::TransformException& ex) {
                ROS_WARN("坐标转换出错: %s", ex.what());
                ros::Duration(0.1).sleep();
                continue;
            }

            // 计算目标方向
            double dx = target_pose_.pose.position.x - transform.transform.translation.x;
            double dy = target_pose_.pose.position.y - transform.transform.translation.y;
            double distance = sqrt(dx*dx + dy*dy);
            double yaw_target = atan2(dy, dx);

            // 获取当前朝向
            tf2::Quaternion q_current(
                transform.transform.rotation.x,
                transform.transform.rotation.y,
                transform.transform.rotation.z,
                transform.transform.rotation.w
            );
            double yaw_current = tf2::getYaw(q_current);    // 获取当前朝向

            // 计算角度误差（归一化到[-π, π]）
            double angle_error = yaw_target - yaw_current;
            angle_error = atan2(sin(angle_error), cos(angle_error));

            // 发布反馈
            burger::TurtleBot3NavigateToGoalFeedback feedback;
            feedback.current_pose.position.x = transform.transform.translation.x;
            feedback.current_pose.position.y = transform.transform.translation.y;
            feedback.distance_to_goal = distance;
            action_server_.publishFeedback(feedback);

            geometry_msgs::Twist cmd_vel;

            if (distance < 0.1) {
                // 到达目标点
                cmd_vel.linear.x = 0.0;
                cmd_vel.angular.z = 0.0;
                vel_pub_.publish(cmd_vel);
                action_server_.setSucceeded();
                
                ROS_INFO("到达目标点!");
                
                break;
            } else if (fabs(angle_error) > 0.1) {
                // 优先调整方向
                cmd_vel.linear.x = 0.0;
                cmd_vel.angular.z = 0.3 * angle_error;
                ROS_INFO("调整角度: 角度误差=%.2f rad, 角速度=%.2f", angle_error, cmd_vel.angular.z);
            } else {
                // 方向对准后前进
                cmd_vel.linear.x = std::min(0.3 * distance, 0.7);
                cmd_vel.angular.z = 1.0 * angle_error; // 微调角度
                ROS_INFO("向前进: 线速度=%.2f, 角速度=%.2f", cmd_vel.linear.x, cmd_vel.angular.z);
            }

            vel_pub_.publish(cmd_vel);
            rate.sleep();
        }
    }
};

int main(int argc, char** argv) {
    ros::init(argc, argv, "navigation_action_server");
    ros::NodeHandle nh;
    setlocale(LC_ALL, ""); 
    NavigationActionServer server(&nh);
    ros::spin();
    return 0;
}