#include <ros/ros.h>
#include <actionlib/client/simple_action_client.h>
#include <geometry_msgs/Point.h>
#include "burger/SetGoal.h"          // 替换为实际包名
#include "burger/TurtleBot3NavigateToGoalAction.h"  // 替换为实际包名

typedef actionlib::SimpleActionClient<burger::TurtleBot3NavigateToGoalAction> ActionClient;

class GoalServiceServer {
private:
    ros::ServiceServer service_;
    ActionClient action_client_;

public:
    GoalServiceServer(ros::NodeHandle* nh) : 
        action_client_("navigate_to_goal", true) {
        service_ = nh->advertiseService("set_goal", &GoalServiceServer::handleGoalRequest, this);
        ROS_INFO("等待服务启动");
        action_client_.waitForServer();
        ROS_INFO("连接到服务器，准备出发");
    }

    bool handleGoalRequest(
        burger::SetGoal::Request& req,
        burger::SetGoal::Response& res
    ) {
        burger::TurtleBot3NavigateToGoalGoal goal;
        goal.target_pos.header.frame_id = "odom";  // 使用 odom 坐标系
        goal.target_pos.pose.position = req.goal;

        action_client_.sendGoal(goal);
        bool finished = action_client_.waitForResult(ros::Duration(30.0));
        
        if (finished) {
            auto result = action_client_.getResult();
            res.success = true;
            res.message = result->message;
        }
        return true;
    }
};

int main(int argc, char** argv) {
    ros::init(argc, argv, "goal_service_server");
    ros::NodeHandle nh;
    setlocale(LC_ALL, "");
    GoalServiceServer server(&nh);
    ros::spin();
    return 0;
}